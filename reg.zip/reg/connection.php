
<?php
$servername = "localhost";
$username = "phpmyadmin";
$password = "chat1@";
$dbname = "chat";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
$rt=array();
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}






 ?>

